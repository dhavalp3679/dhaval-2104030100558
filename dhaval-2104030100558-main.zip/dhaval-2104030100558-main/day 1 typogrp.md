# dhaval-2104030100558
html 1 day 
<!DOCTYPE html>
<html>
    <head>
            <title>day 1 typogrp</title>
    </head>
    <body>
 <!----------HEADING------------>       
          <h1>THE TIME OF INDIA</h1>
          <h2>VAN BANNER</h2>
          <h3>THE TELEGRAPH</h3>
          <h4>DECCAN CHRONICLE</h4>
          <h5>BANNER HEADLINE</h5>
          <h6>NEWS LETTER</h6>
<!----------------paragraph element--------->
          <p>The film 300 recounts one of the greatest battles in history </p>        
<!---------------bold text---------------->          
          <b>As the Persian army is about to descend upon the small force of Spartans.</b><br>  
          <strong>As the Persian army is about to descend upon the small force of Spartans.</strong><br>
<!-----------ITALIFC STYLE-------------->
          <i>The Roman historian and philosopher Plutarch actually recorded this real-life exchange. </i><br>
          <italics>The Roman historian and philosopher Plutarch actually recorded this real-life exchange.</italics>
          <!----------------LINK TAG-------------------->
          <br><a href="https://www.google.com/" > google</a>
          <br><a href="https://www.facebook.com/" target="_blank"> facebook</a>
          <br><a href="https://web.whatsapp.com/" mailto:dhavalp3679@gmail.com> whatsapp WEB</a>
          <br><a href="http://mail.google.com/mail/ " mailto:dhavalp3679@gmail.com> mail</a>
<!----------------OREDERED LIST----------------------->
          <ol>
              <li>phone</li>
              <li>computer</li>
              <li>laptop</li>
              <li>tv</li>
          </ol>

<!-----------------Vnordesed list----------------------------->

          
<ul>
    <li>home</li>
    <li>about</li>
    <li>account</li>
</ul>

<!--------------------Big and small--------------------------->

<big>this name harshida</big><br>
<small>this name harshida</small>

<!---------------------subscript and supercriet------------------------------>

<p>co<sub>2</sub></p>
<p>a<sup>2</sup>+bs</p>

<!------------------------personal rescue enclosure------------------------------>

<pre>
    this is urritten 
    using pre 
    tag
</pre>
<!----------------------span tag---------------------->

<span>
     i am webiste developer 
</span><br>
<span>
    i am webiste developer css
</span><br>

<!-----------------short inline quptation------------------------->

<q>Build a future where people live in harmony with nature.</q>
<P>"Build a future where people live in harmony with nature."</P>
    </body>
</html>